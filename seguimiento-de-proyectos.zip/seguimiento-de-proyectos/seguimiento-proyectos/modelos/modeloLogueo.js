var conexion = require("../conexiones/connMySQL");

var modelo = function(){};

modelo.validar = function(correo, contrasena, cb){
	conexion.query("select * from usuarios where UsuCorStr=? and UsuPasStr=?", [correo, contrasena], cb);
};

modelo.detalleUsuario = function(correo, cb){
	conexion.query("select * from usuarios where UsuCorStr=?", correo, cb);
}

module.exports = modelo;