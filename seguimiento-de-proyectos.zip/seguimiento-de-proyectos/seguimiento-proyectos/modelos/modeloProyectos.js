var conexion = require('../conexiones/connMySQL');

var modelo = function(){};

modelo.listar = function(cb){
	conexion.query("select * from proyectos", cb);
}

modelo.actualizarListar = function(id, cb){
	conexion.query("select * from proyectos where PryIdNum=? ", id, cb);
}

modelo.listarPryPorUsuario = function(UsuCorreo, cb){
	conexion.query("select * from proyectos where UsuCorStr=?", UsuCorreo, cb);
}

modelo.listarUsuPorProyecto = function(id, cb){
	conexion.query("select * from proyectos where PryIdNum=?", id, cb);
}

modelo.actualizar = function(id, registro, cb){
	conexion.query("update proyectos set PryNomStr=?, PryHorNum=?, UsuCorStr=? where PryIdNum=?", [registro.nombre, registro.horas, registro.usuarioCorreo, id], cb);
}

modelo.actualizarAsignaHoras = function(id, registro, cb){
	conexion.query("update proyectos set PryHorNum=?, UsuCorStr=? where PryIdNum=?", [registro.horas, registro.usuarioCorreo, id], cb)
}

modelo.eliminar = function(id, cb){
	conexion.query("delete from proyectos where PryIdNum=?", id, cb);
}

modelo.insertar = function(registro, cb){
	conexion.query("insert into proyectos set ?", registro, cb);
}

module.exports = modelo;