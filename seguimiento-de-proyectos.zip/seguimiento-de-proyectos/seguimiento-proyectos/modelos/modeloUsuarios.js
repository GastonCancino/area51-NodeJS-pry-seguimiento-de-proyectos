var conexion = require("../conexiones/connMySQL");

var modelo = function(){};

modelo.listar = function(cb){
	conexion.query("select * from usuarios", cb);
}

modelo.actualizarListar = function(id, cb){
	conexion.query("select * from usuarios where UsuCorStr=?", id, cb);
}

modelo.actualizar = function(id, registro, cb){
	conexion.query("update usuarios set UsuCorStr=?, UsuNomStr=?, UsuCarStr=?, UsuAreStr=? where UsuCorStr=?", [registro.correo, registro.nombre, registro.cargo, registro.area, id], cb)
}

modelo.eliminar = function(id, cb){
	conexion.query("delete from usuarios where UsuCorStr=?", id, cb);
}

modelo.insertar = function(registro, cb){
	conexion.query("insert into usuarios set ?", registro, cb);
}

module.exports = modelo;