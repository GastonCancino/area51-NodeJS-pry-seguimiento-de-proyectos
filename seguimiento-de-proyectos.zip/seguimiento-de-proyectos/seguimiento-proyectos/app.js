var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var cookieSession = require('cookie-session');

var modelo = require('./modelos/modeloLogueo')

var passport = require('passport');
var passportLocal = require('passport-local').Strategy;

var passportFacebook = require('passport-facebook').Strategy;
var passportGoogle = require('passport-google-oauth2').Strategy;
var passportTwitter = require('passport-twitter').Strategy;

var credenciales = require("./credenciales");

var routes = require('./routes/index');
var users = require('./routes/users');

var app = express();

passport.serializeUser(function(usuario, done){
  // INICIO para validación por REDES SOCIALES
  done(null, usuario);
  // FIN para validación por REDES SOCIALES


  // INICIO para validación por BD
  //done(null, usuario.correo);
  // FIN para validación por BD
});

passport.deserializeUser(function(correo, done){
  // INICIO para validación por REDES SOCIALES
  done(null, correo);
  // FIN para validación por REDES SOCIALES

  // INICIO para validación por BD
  /*
  modelo.detalleUsuario(correo, function(err, registros){
    if(err){
      done(err);
    } else if(registros.length==0){
      done(null, false);
    } else{
      done(null, registros[0]);
    }
  });
*/

// FIN para validación por BD
});

// PASSPORT FACEBOOK
passport.use(new passportFacebook({
  clientID:     credenciales.facebook.claveServidor, //"1673311979584224",
  clientSecret: credenciales.facebook.claveSecreta,  //"eb5be48fdd5ff795d51fdaa2871c289e",
  callbackURL:  credenciales.facebook.rutaCallback,  //"http://localhost:3000/facebook/callback",
  profileFields: ['id', 'displayName', 'photos']
}, function(accessToken, refreshToken, profile, done){
  return done(null, {id: profile.id, proveedor: profile.provider, usuario: profile.displayName, 
    foto: profile.photos[0].value});
}));


// PASSPORT GOOGLE
passport.use(new passportGoogle({
  clientID:     credenciales.google.claveServidor, //"186812544439-b5bcfd7hsfrl8obdf0k3o9751lg2268t.apps.googleusercontent.com",
  clientSecret: credenciales.google.claveSecreta, //"pBWzJsVztRIpmnqKIWxjGuQu",
  callbackURL:  credenciales.google.rutaCallback,  //"http://localhost:3000/google/callback"
}, function(accessToken, refreshToken, profile, done) {
  return done(null, {id: profile.id, proveedor: profile.provider, usuario: profile.displayName, 
    foto: profile._json.image.url});
}));


// PASSPORT TWITTER
passport.use(new passportTwitter({
  consumerKey:    credenciales.twitter.claveServidor, //"k3jhLlEmqF4bIvpUx694bnkJ1",
  consumerSecret: credenciales.twitter.claveSecreta, //"KHWUu5Hwcol2vstyHrArgMwb2ldzmqVmOax7yEFkHjhW0LuEhD",
  callbackURL:    credenciales.twitter.rutaCallback, //"http://127.0.0.1:3000/twitter/callback"
}, function(accessToken, refreshToken, profile, done){
  return done(null, {id: profile.id, proveedor: profile.provider, usuario: profile.displayName,
    foto: profile.photos[0].value});
}));


// LOCAL
passport.use(new passportLocal(
{
  usernameField: "UsuCorStr",
  passwordField: "UsuPasStr"
},
function(username, password, done){
  console.log("Usuario: "+username);
  console.log("Contraseña: "+password);

  // INICIO para validación por BD
  modelo.validar(username, password, function(err, registros){
    if(err){
      return done(err);
    }

    if(registros.length){
      var usuario = {correo: registros[0].UsuCorStr, nombre: registros[0].UsuNomStr};
      return done(null, usuario);
    } else{
      return done(null, false);
    }

  });
  // FIN para validación por BD

} ));


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(cookieSession({secret: "nodejs"}));
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());
app.use(passport.session());

app.use('/', routes);
app.use('/users', users);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
