var modelo = require("../modelos/modeloUsuarios");

var controlador = function(){};

controlador.listar = function(req, res){
	
	modelo.listar(function(err, registros){
		if(err){
			console.log('Error en la consulta de usuarios:' + err);
		} else{
			var datos = {
				registros: registros
			};
			res.render("usuarios", datos);
		}
	});
}

controlador.listarReportPorUsuario = function(req, res, next){
	var UsuCorreo = req.body.UsuCorStr;

	modelo.listar(function(err, registros){
		if(err){
			console.log('Error en la consulta de usuarios:' + err);
		} else{

			if(UsuCorreo){
				var datos = {
					UsuCorreo: UsuCorreo,
					registrosUsu: registros
				};
				//res.render("reportPorUsuario2", datos);
				req.UsuCorreo = UsuCorreo;
				req.usuarios  = registros;
				next();
			} else{
				var datos = {
					UsuCorreo: UsuCorreo,
					registrosUsu: registros
				};

				res.render("reportPorUsuario", datos);
			}
		}
	});
}


// TRAE los datos de la tabla usuarios para pasarlos hacia controladorProyectos.listarPryAsignaHoras para 
// la pagina asignaHoras.ejs
controlador.listarUsuYpasarlosAotroControlador = function(req, res, next){

	modelo.listar(function(err, registros){
		if(err){
			console.log('Error en la consulta de usuarios:' + err);
		} else{
			var datos = {
				registrosUsu: registros
			};
			//res.render("reportPorUsuario", datos);

			// setear los registros de la tabla usuarios en el req:
			req.registrosUsu = registros;

			// pasamos el req.registrosUsu hacia controladorProyectos.listarPryAsignaHoras:
			next();
		}
	});
}

// MUESTRA los datos del usuario que se va a modificar:
controlador.actualizarListar = function(req, res){
	var id = req.params.id;

	modelo.actualizarListar(id, function(err, registros){
		if(err){
			console.log('Error al traer registro de usuario para editar:' + err);
		} else{
			datos = {
				registro: registros[0]
			};

			res.render('formActualizarUsu', datos);
		}
	});
}



// ACTUALIZA los datos del usuario que se va a modificar:
controlador.actualizar = function(req, res){
	var id = req.params.id;

	var correo = req.body.UsuarioCorreo, // este nombre tiene que ser el mismo al del formulario
		nombre = req.body.UsuarioNombre, // este nombre tiene que ser el mismo al del formulario
		cargo = req.body.UsuarioCargo,   // este nombre tiene que ser el mismo al del formulario
		area = req.body.UsuarioArea;     // este nombre tiene que ser el mismo al del formulario

	var registro = {
		correo: correo,
		nombre: nombre,
		cargo: cargo,
		area: area
	}

	modelo.actualizar(id, registro, function(err){
		if(err){
			console.log('Error no se pudo actualizar el registro del usuario:' + err);
		} else{
			res.redirect('/usuarios');
		}
	});
}


// ELIMINA el usuario:
controlador.eliminar = function(req, res){
	var id = req.params.id;

	modelo.eliminar(id, function(err){
		if(err){
			console.log('Error no se pudo eliminar el registro del usuario:' + err);
		} else{
			res.redirect('/usuarios');
		}
	});
}



// LLAMAR al formulario de nuevo usuario
controlador.formInsertar = function(req, res){
	res.render("formAgregarusuario");
}


// INSERTA un nuevo usuario
controlador.insertar = function(req, res){
	var correo = req.body.CorreoUsuario,
		contrasena = req.body.ContrasenaUsuario,
		nombre = req.body.NombreUsuario,
		cargo = req.body.CargoUsuario,
		area = req.body.AreaUsuario;

		var registro = {
			UsuCorStr: correo,
			UsuPasStr: contrasena,
			UsuNomStr: nombre,
			UsuCarStr: cargo,
			UsuAreStr: area
		}

		modelo.insertar(registro, function(err){
			if(err){
				console.log('Error no se pudo insertar el registro del nuevo usuario:' + err);
			} else{
				res.redirect('/usuarios');
			}
		});
}


module.exports = controlador;