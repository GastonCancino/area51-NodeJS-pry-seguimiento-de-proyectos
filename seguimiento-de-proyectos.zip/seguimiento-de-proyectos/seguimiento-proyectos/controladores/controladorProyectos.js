var modelo = require('../modelos/modeloProyectos');

var controlador = function(){};

controlador.listar = function(req, res){
	// recibo el parámetro enviado desde la tabla, para saber si llevo a la página que hara el CRUD.
	var mantenimiento = req.params.mante;

	modelo.listar(function(err, registros){
		if(err){
			console.log('Error en la consulta de proyectos:' + err);
		} else{
			var datos = {
				registros: registros
			};

			// enviar a la página que hará el CRUD de los proyectos.
			if(mantenimiento=='CRUD'){
				res.render('proyectos', datos);
			} else{
				res.render('resumen', datos);
			}
		}
	});
}

controlador.listarReportPorProyecto = function(req, res, next){
	var IdProyecto = req.body.PryIdNum;

	modelo.listar(function(err, registros){
		if(err){
			console.log('Error en la consulta de proyectos:' + err);
		} else{

			if(IdProyecto){
				var datos = {
					IdProyecto: IdProyecto,
					registrosPry: registros
				};

				//res.render("reportPorUsuario2", datos);
				req.IdProyecto = IdProyecto;
				req.proyectos  = registros;
				next();
			} else{
				var datos = {
					registrosPry: registros
				};

				res.render("reportPorProyecto", datos);
			}
		}
	});
}



// LISTA USUARIOS POR PROYECTO:
controlador.listarUsuPorProyecto = function(req, res, done){
	var IdProyecto = req.IdProyecto,
		proyectos = req.proyectos;

	modelo.listarUsuPorProyecto(IdProyecto, function(err, registros){
		if(err){
			console.log('Error al traer los usurios del proyecto:' + err);
		} else if(registros.length==0){
			var datos = {
				IdProyecto: IdProyecto,
				registrosUsu: registros,
				registrosPry: proyectos
			}
			return done(null, res.render('reportPorProyecto', datos));

		} else{
			var datos = {
				IdProyecto: IdProyecto,
				registrosUsu: registros,
				registrosPry: proyectos
			}
			res.render("reportPorProyecto2", datos);
		}
	});
	
}



// RECIBIR los registros de la tabla usuarios que vienen de controlador.listarUsuAsignaHoras
// y pasarlos junto con los datos de los proyectos hacia la página asignaHoras
controlador.listarPryAsignaHoras = function(req, res, next){

	modelo.listar(function(err, registros){
		if(err){
			console.log('Error en la consulta de proyectos para asignar horas:' + err);
		} else{

			var datos = {
				// recuperar los registros de la tabla usuarios seteados en req.registrosUsu de 
				// controladorUsuarios.js:
				registrosUsuarios: req.registrosUsu,
				registrosProyectos: registros
			};

			// enviar los registros de la tabla usuarios y proyectos a la página asignaHoras.ejs
			res.render('formAsignaHoras', datos);
		}
	})
}


// MUESTRA los datos el proyecto que se va a modificar:
controlador.actualizarListar = function(req, res){
	var id = req.params.id;

	modelo.actualizarListar(id, function(err, registros){
		if(err){
			console.log('Error al traer registro de proyecto para editar:' + err);
		} else{
			var datos = {
				// recuperamos los registros de la tabla usuarios seteados en req.registrosUsu 
				// de controladorUsuarios.js:
				registrosUsuarios: req.registrosUsu,
				registro: registros[0]
			};

			res.render('formActualizar', datos);
		}
	});
}


// LISTA PROYECTOS POR USUARIO:
controlador.listarPryPorUsuario = function(req, res, done){
	var UsuCorreo = req.UsuCorreo,
		usuarios = req.usuarios;

	modelo.listarPryPorUsuario(UsuCorreo, function(err, registros){
		if(err){
			console.log('Error al traer los proyectos de un usuario:' + err);
		} else if(registros.length==0){
			var datos = {
				UsuarioCorreo: UsuCorreo,
				registrosUsu: usuarios
			}
			return done(null, res.render('reportPorUsuario', datos));
		} else{
			var datos = {
				UsuarioCorreo: UsuCorreo,
				registrosUsu: usuarios,
				registrosPry: registros
			}
			res.render("reportPorUsuario2", datos);
		}
	});
	
}


// ACTUALIZA los datos del proyecto que se va a modificar:
controlador.actualizar = function(req, res){
	var id = req.params.id;
	var nombre = req.body.PryNomStr,        // este nombre tiene que ser el mismo al del formulario
		horas = req.body.PryHorNum,         // este nombre tiene que ser el mismo al del formulario
		usuarioCorreo = req.body.UsuCorStr; // este nombre tiene que ser el mismo al del formulario

	var registro = {
		nombre: nombre,
		horas: horas,
		usuarioCorreo: usuarioCorreo
	}

	modelo.actualizar(id, registro, function(err){
		if(err){
			console.log('Error al querer actualizar el registro del proyecto:' + err);
		} else{
			res.redirect('/proyectos/CRUD');
		}
	});
}


// ASIGNA HORAS al proyecto:
controlador.actualizarAsignaHoras = function(req, res){
	var id = req.body.PryIdNum,
		horas = req.body.PryHorNum,
		usuarioCorreo = req.body.UsuCorStr;
	var registro = {
		horas: horas,
		usuarioCorreo: usuarioCorreo
	}

	modelo.actualizarAsignaHoras(id, registro, function(err){
		if(err){
			console.log('Error al querer actualizar la asignación de horas del proyecto:' + err);
		} else{
			res.redirect('/formAsignaHoras');
		}
	});
}


// ELIMINA el proyecto seleccionado:
controlador.eliminar = function(req, res){
	var id = req.params.id;

	modelo.eliminar(id, function(err){
		if(err){
			console.log('Error al querer eliminar el proyecto:' + err);
		} else{
			res.redirect('/proyectos/CRUD');
		}
	});
}



// LLAMA al formulario de nuevo proyecto:
controlador.formInsertar = function(req, res){
	res.render("formAgregarProyecto");
}

// INSERTA un nuevo proyecto:
controlador.insertar = function(req, res){
	var nombre = req.body.NombreProyecto;

	var registro = {
		PryNomStr: nombre
	}

	modelo.insertar(registro, function(err){
		if(err){
			console.log('Error al querer insertar registro de nuevo proyecto:' + err);
		} else{
			res.redirect('/proyectos/CRUD');
		}
	});
}

module.exports = controlador;