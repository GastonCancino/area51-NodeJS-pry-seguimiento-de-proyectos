var credenciales = {
	facebook: {
		claveServidor: "1673311979584224",
		claveSecreta: "eb5be48fdd5ff795d51fdaa2871c289e",
		rutaCallback: "http://localhost:3000/facebook/callback"
	},
	google: {
		claveServidor: "186812544439-b5bcfd7hsfrl8obdf0k3o9751lg2268t.apps.googleusercontent.com",
		claveSecreta: "pBWzJsVztRIpmnqKIWxjGuQu",
		rutaCallback: "http://localhost:3000/google/callback"
	},
	twitter: {
		claveServidor: "k3jhLlEmqF4bIvpUx694bnkJ1",
		claveSecreta: "KHWUu5Hwcol2vstyHrArgMwb2ldzmqVmOax7yEFkHjhW0LuEhD",
		rutaCallback: "http://127.0.0.1:3000/twitter/callback"
	}
};

module.exports = credenciales;