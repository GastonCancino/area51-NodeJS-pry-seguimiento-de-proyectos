var express = require('express');
var router = express.Router();
var passport = require('passport');
var controladorUsuarios = require('../controladores/controladorUsuarios');
var controladorProyectos = require('../controladores/controladorProyectos');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});
/*
router.get("/usuario", function(req,res){
  res.send("Autenticado");
});
*/

//FACEBOOK
router.get('/loginFacebook', passport.authenticate('facebook'));

router.get('/facebook/callback', passport.authenticate('facebook', 
	//{successRedirect: '/usuario', failureRedirect: '/'}
	{successRedirect: '/resumen', failureRedirect: '/'}
));


// GOOGLE
router.get('/loginGoogle',passport.authenticate('google', {scope:[
	'https://www.googleapis.com/auth/plus.login', 
	'https://www.googleapis.com/auth/plus.profile.emails.read'
	]}));

router.get('/google/callback', passport.authenticate('google',
	//{successRedirect: '/usuario', failureRedirect: '/'}
	{successRedirect: '/resumen', failureRedirect: '/'}
));


// TWITTER
router.get('/loginTwitter', passport.authenticate('twitter'));

router.get('/twitter/callback', passport.authenticate('twitter',
	//{successRedirect: '/usuario', failureRedirect: '/'}
	{successRedirect: '/resumen', failureRedirect: '/'}
));





/* ---------------- INICIO autenticación con base de datos ---------------- */
router.post('/loguear', passport.authenticate('local', {
	successRedirect: '/resumen',
	//successRedirect: '/autenticado',
	failureRedirect: '/'
}));

router.get("/autenticado", function(req, res, next){
  res.render("autenticado", req.user);
});
/* ---------------- FIN autenticación con base de datos ---------------- */



/* ------------------------------ INICIO PROYECTOS ------------------------------ */

// llamando a la página que lista los proyectos como resumen:
router.get('/resumen', controladorProyectos.listar);

// llamando a la página de mantenimiento de proyectos:
router.get('/proyectos/:mante', controladorProyectos.listar);

	// llamando al formulario que sirve para cambiar los datos:
	router.get('/formActualizar/:id', controladorUsuarios.listarUsuYpasarlosAotroControlador, 
		controladorProyectos.actualizarListar);

	// llamando a actualizar, para modificar los datos. Aca debe ser post porque el action del form es asi:
	router.post('/actualizar/:id', controladorProyectos.actualizar);

// llamando a eliminar, para eliminar un proyecto:
router.get('/eliminar/:id', controladorProyectos.eliminar);

// llamando al formulario para agregar nuevo proyecto:
router.get('/formAgregarProyecto', controladorProyectos.formInsertar);

	// llamando a insertar, para insertar el nuevo proyecto:
	router.post('/insertarProyecto', controladorProyectos.insertar);

/* ------------------------------ FIN PROYECTOS ------------------------------ */



/* ------------------------------ INICIO USUARIOS ------------------------------ */

// llamando a la página que lista los usuarios:
router.get('/usuarios', controladorUsuarios.listar);

// llamando al formulario que sirve para cambiar los datos:
router.get('/formActualizarUsu/:id', controladorUsuarios.actualizarListar);

	// llamando a actualizar, para modificar los datos. Aca debe ser post porque el action del form es asi:
	router.post('/actualizarUsu/:id', controladorUsuarios.actualizar);

// llamando a eliminar, para eliminar usuario:
router.get('/eliminarUsu/:id', controladorUsuarios.eliminar);

// llamando al formulario para agregar nuevo usuario:
router.get('/formAgregarUsuario', controladorUsuarios.formInsertar);

	// llamando a insertar, para insertar el nuevo usuario
	router.post('/insertarUsuario', controladorUsuarios.insertar);

/* ------------------------------ FIN USUARIOS ------------------------------ */


/* ------------------------------ INICIO ASIGNACION DE HORAS ------------------------------ */

router.get('/formAsignaHoras', controladorUsuarios.listarUsuYpasarlosAotroControlador, 
	controladorProyectos.listarPryAsignaHoras);

// llamando a actualizar, para modificar los datos del proyecto.
router.post('/actualizarAsignaHoras', controladorProyectos.actualizarAsignaHoras);

/* ------------------------------ FIN ASIGNACION DE HORAS ------------------------------ */



/* ------------------------------ INICIO REPORTE POR USUARIO ------------------------------ */
router.get('/reportPorUsuario', controladorUsuarios.listarReportPorUsuario);

router.post('/reportPorUsuario2', controladorUsuarios.listarReportPorUsuario, 
	controladorProyectos.listarPryPorUsuario);
/* ------------------------------ FIN REPORTE POR USUARIO ------------------------------ */



/* ------------------------------ INICIO REPORTE POR PROYECTO ------------------------------ */
router.get('/reportPorProyecto', controladorProyectos.listarReportPorProyecto);

router.post('/reportPorProyecto2', controladorProyectos.listarReportPorProyecto, 
	controladorProyectos.listarUsuPorProyecto);
/* ------------------------------ FIN REPORTE POR PROYECTO ------------------------------ */


router.get('/logout', function(req, res){
	req.logout();
	res.redirect("/");
});

module.exports = router;
