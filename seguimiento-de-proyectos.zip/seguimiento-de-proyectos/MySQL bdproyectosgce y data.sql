/*
SQLyog Enterprise - MySQL GUI v8.05 
MySQL - 5.0.51b-community-nt-log : Database - bdproyectosgce
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`bdproyectosgce` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci */;

USE `bdproyectosgce`;

/*Table structure for table `proyectos` */

DROP TABLE IF EXISTS `proyectos`;

CREATE TABLE `proyectos` (
  `PryIdNum` int(10) NOT NULL auto_increment COMMENT 'ID de proyecto',
  `PryNomStr` varchar(100) collate utf8_spanish_ci default NULL COMMENT 'Nombre del proyecto',
  `PryHorNum` int(4) default NULL COMMENT 'Horas consumidas en el proyecto',
  `UsuCorStr` varchar(50) collate utf8_spanish_ci default NULL COMMENT 'Correo de usuario (id)',
  PRIMARY KEY  (`PryIdNum`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

/*Data for the table `proyectos` */

insert  into `proyectos`(`PryIdNum`,`PryNomStr`,`PryHorNum`,`UsuCorStr`) values (1,'Alineamiento de Cartera en SENTINEL',81,'gastonchiquillo@yahoo.es'),(2,'Consultar estado actual de riesgo financiero SENTINEL',115,'mickey.mouse@yahoo.es'),(3,'Reportes PDF de persona consultada en SENTINEL',50,'sergiohidalgocaceres@gmail.com'),(4,'Semaforización de persona consultada en SENTINEL',45,'sergiohidalgocaceres@gmail.com'),(5,'Desarrollo de módulo de discrepancias en intranet',60,'gastonchiquillo@yahoo.es'),(6,'Desarrollo de producto MyPE consulta reporte de deudas',400,'stefani.rodriguez@gmail.com'),(7,'Envio de email con reporte de deuda en producto MyPE',20,'gastonchiquillo@yahoo.es'),(8,'Marca de personas para seguimiento de alertas en deudas de MyPE',40,'gastonchiquillo@yahoo.es'),(10,'Desarrollo de módulo evaluación crediticia en SENTINEL',100,'carla.tarasona@gmail.com'),(14,'Desarrollo de nuevo producto COSECHAS',NULL,NULL);

/*Table structure for table `usuarios` */

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `UsuCorStr` varchar(50) collate utf8_spanish_ci NOT NULL COMMENT 'Correo',
  `UsuPasStr` varchar(20) collate utf8_spanish_ci NOT NULL COMMENT 'Password',
  `UsuNomStr` varchar(50) collate utf8_spanish_ci default NULL COMMENT 'Nombre',
  `UsuCarStr` varchar(50) collate utf8_spanish_ci default NULL COMMENT 'Cargo',
  `UsuAreStr` varchar(50) collate utf8_spanish_ci default NULL COMMENT 'Area',
  PRIMARY KEY  (`UsuCorStr`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

/*Data for the table `usuarios` */

insert  into `usuarios`(`UsuCorStr`,`UsuPasStr`,`UsuNomStr`,`UsuCarStr`,`UsuAreStr`) values ('gastonchiquillo@yahoo.es','123456','Guido Gaston Cancino','Analista Programador de Sistemas','Sistemas'),('sergiohidalgocaceres@gmail.com','123','Sergio Hidalgo','Gestor de Proyectos (PMP)','PMO'),('stefani.rodriguez@gmail.com','123456789','Stefani Rodriguez','Desarrollador','Sistemas'),('carla.tarasona@gmail.com','223','Carla Tarasona','Desarrollador','Sistemas'),('yoana.silvera@gmail.com','552','Yoana Silvera','Desarrollador','Sistemas'),('mickey.mouse@yahoo.es','152','Mickey Mouse','Comunicador infantil','Marketing');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
